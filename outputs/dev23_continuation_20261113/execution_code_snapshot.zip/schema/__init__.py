"""Ontology schema retrieval helpers."""
