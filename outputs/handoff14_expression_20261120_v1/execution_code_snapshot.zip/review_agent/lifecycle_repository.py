"""Additive candidate workflow, issue events and extension-request subscriptions."""

import json
import sqlite3
from uuid import uuid4

from .contracts import canonical_json, sha256_json

WAITING_STATES = {"awaiting_ontology_review", "awaiting_ontology_release", "reaudit_required", "schema_unresolved"}


class LifecycleRepository:
    def ensure_lifecycle_backup(self):
        if not self.database_path.exists() or not self.database_path.stat().st_size:
            return
        source = sqlite3.connect(self.database_path.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            columns = {row[1] for row in source.execute("PRAGMA table_info(candidates)")}
            if not columns:
                return
            has_agent = source.execute("SELECT 1 FROM sqlite_master WHERE name='ontology_audits'").fetchone()
            has_admission = source.execute("SELECT 1 FROM sqlite_master WHERE name='graph_sync'").fetchone()
            if "workflow_state" in columns and has_agent and has_admission: return
            folder = self.database_path.parent / "migration_backups"
            folder.mkdir(parents=True, exist_ok=True)
            version = "v6" if has_agent and "workflow_state" in columns else "v5" if "workflow_state" in columns else "v4"
            target = folder / (self.database_path.stem + ".pre_" + version + "." + uuid4().hex + ".sqlite3")
            destination = sqlite3.connect(target)
            try: source.backup(destination)
            finally: destination.close()
        finally:
            source.close()

    def initialize_lifecycle(self, connection):
        if not connection.in_transaction: connection.execute("BEGIN IMMEDIATE")
        columns = {row[1] for row in connection.execute("PRAGMA table_info(candidates)")}
        for name, ddl in (("workflow_state", "TEXT NOT NULL DEFAULT 'ready_for_review'"),
                          ("pending_extension_id", "TEXT")):
            if name not in columns: connection.execute(f"ALTER TABLE candidates ADD COLUMN {name} {ddl}")
        statements = [
            "CREATE TABLE IF NOT EXISTS issue_events(event_id TEXT PRIMARY KEY,audit_id TEXT NOT NULL REFERENCES audit_runs(audit_id),issue_id TEXT NOT NULL,event_json TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS ontology_extension_tasks(extension_id TEXT PRIMARY KEY,gap_key TEXT NOT NULL UNIQUE,base_release_id TEXT NOT NULL,base_ontology_version TEXT NOT NULL,base_profile_hash TEXT NOT NULL,status TEXT NOT NULL,task_json TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS ontology_extension_subscriptions(extension_id TEXT NOT NULL REFERENCES ontology_extension_tasks(extension_id),candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),revision INTEGER NOT NULL,expected_row_version INTEGER NOT NULL,source_proposal_digest TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'active',PRIMARY KEY(extension_id,candidate_id,revision))",
        ]
        for statement in statements: connection.execute(statement)

    def record_issue_events(self, audit_id, events):
        if not events: return
        with self.transaction(immediate=True) as connection:
            for event in events:
                connection.execute("INSERT OR IGNORE INTO issue_events(event_id,audit_id,issue_id,event_json) VALUES(?,?,?,?)",
                                   (event["event_id"], audit_id, event["issue_id"], canonical_json(event)))

    def create_extension_request(self, candidate, *, expected_row_version, proposal, change_kind,
                                 description, proposed_changes, evidence_ids, full_lookup):
        from .repository import ConflictError, ValidationError
        base = {key: candidate.get(key) for key in ("ontology_release_id", "ontology_version", "profile_hash")}
        if not all(base.values()): raise ValidationError("extension requires an immutable release/profile binding")
        if full_lookup.get("scope") != "full_frozen_ontology" or full_lookup.get("candidate_revision") != candidate["revision"]:
            raise ValidationError("extension requires a current full-schema lookup")
        if any(full_lookup.get(key) != base[key] for key in ("ontology_version", "ontology_release_id", "profile_hash")):
            raise ValidationError("extension full-schema lookup release/profile mismatch")
        # Aggregate actual missing expressions, not model prose or a fabricated ID.
        triple = candidate["triple"]
        gap_key = sha256_json([base, change_kind, " ".join(str(triple.get("surface_relation") or triple.get("relation_id") or "").split()).casefold(),
                               triple.get("head_type"), triple.get("tail_type")])
        legacy_gap_key=gap_key
        def target_identity(changes):
            from ontologyBuild.ontology_adapter import normalize_name
            if change_kind=='add_class': return ['class',normalize_name(changes.get('label') or changes.get('name'))]
            if change_kind=='add_alias': return ['alias',changes.get('term_id') or changes.get('target_id'),normalize_name(changes.get('alias'))]
            if change_kind=='merge_terms': return ['merge',sorted(changes.get('term_ids') or [])]
            if change_kind in {'revise_definition','revise_constraint'}: return ['revision',changes]
            return None
        identity=target_identity(proposed_changes)
        if identity is not None: gap_key=sha256_json([legacy_gap_key,identity])
        if change_kind=='revise_definition' and full_lookup.get('shared_definition_target'):
            target=proposed_changes.get('term_id') or proposed_changes.get('target_id')
            if target!=full_lookup['shared_definition_target']:raise ValidationError('shared definition target differs from exact proposed term')
            gap_key=sha256_json(['shared_definition_v1',base,change_kind,target])
        trigger = {"candidate_id": candidate["candidate_id"], "revision": candidate["revision"],
                   "audit_id": proposal["audit_id"], "round_id": proposal["round_id"],
                   "source_proposal_digest": proposal["proposal_digest"], "evidence_hash": proposal["evidence_bundle"]["evidence_hash"],
                   "evidence_ids": list(evidence_ids), "proposed_changes": proposed_changes}
        resolution=full_lookup.get('source_resolution_snapshot')
        supplement=full_lookup.get('resolved_source_evidence') or []
        if resolution:
            if (resolution.get('candidate_hash')!=sha256_json(candidate) or resolution.get('base_proposal_digest')!=proposal['proposal_digest']
                    or resolution.get('dimension_results',{}).get('source',{}).get('status')!='supported'
                    or resolution.get('dimension_results',{}).get('expression',{}).get('status')!='standard'
                    or set(resolution.get('whole_vote_eligible_voter_ids',[]))!={v['id'] for v in proposal['committee_members']}):
                raise ValidationError('definition evidence requires the exact complete source-resolution snapshot')
        lookup_for_task={k:v for k,v in full_lookup.items() if k not in {'source_resolution_snapshot','resolved_source_evidence'}}
        with self.transaction(immediate=True) as connection:
            row = connection.execute("SELECT * FROM candidates WHERE candidate_id=?", (candidate["candidate_id"],)).fetchone()
            if not row or row["row_version"] != expected_row_version or row["current_revision"] != candidate["revision"] or row["human_status"] != "pending":
                raise ConflictError("candidate changed before ontology subscription")
            if row["pending_extension_id"]:
                raise ConflictError("candidate already has an extension subscription; inspect that task instead")
            stored = connection.execute("SELECT * FROM ontology_extension_tasks WHERE gap_key=?", (gap_key,)).fetchone()
            if not stored and gap_key!=legacy_gap_key:
                legacy=connection.execute('SELECT * FROM ontology_extension_tasks WHERE gap_key=?',(legacy_gap_key,)).fetchone()
                if legacy and target_identity(json.loads(legacy['task_json']).get('proposed_changes',{}))==identity:
                    stored=legacy
            if stored:
                task = json.loads(stored["task_json"])
                task["status"] = stored["status"]
                if trigger not in task.get("trigger_candidates", []):
                    task.setdefault("trigger_candidates", []).append(trigger)
                    task["evidence_ids"] = sorted(set(task.get("evidence_ids", [])) | set(evidence_ids))
                    connection.execute("UPDATE ontology_extension_tasks SET task_json=?,row_version=row_version+1 WHERE extension_id=?", (canonical_json(task), task["extension_id"]))
            else:
                extension_id = "ext_" + uuid4().hex
                task = {"extension_id": extension_id, "contract_version": "ontology_delta_v1", "delta_revision": 1,
                        "base_release_id": base["ontology_release_id"], "base_ontology_version": base["ontology_version"],
                        "base_profile_hash": base["profile_hash"], "change_kind": change_kind, "description": description,
                        "proposed_changes": proposed_changes, "evidence_ids": list(evidence_ids),
                        "existing_schema_search": lookup_for_task, "status": "proposed", "auto_publish_enabled": False,
                        "trigger_candidates": [trigger],
                        "risk_category": "high_impact" if change_kind in {"revise_constraint", "revise_definition", "merge_terms"} else "additive_draft",
                        "ontology_review_executed": False}
                connection.execute("INSERT INTO ontology_extension_tasks(extension_id,gap_key,base_release_id,base_ontology_version,base_profile_hash,status,task_json) VALUES(?,?,?,?,?,?,?)", (extension_id, gap_key,
                    base["ontology_release_id"], base["ontology_version"], base["profile_hash"], "proposed", canonical_json(task)))
            if resolution:
                descriptor={k:resolution.get(k) for k in ('snapshot_id','candidate_hash','evidence_hash','base_proposal_digest','original_votes_hash')}
                task.setdefault('source_support_resolutions',{})[candidate['candidate_id']+':'+str(candidate['revision'])]=descriptor
                if task['status']!='published':
                    existing={e['evidence_id']:e for e in task.get('review_evidence',[])}
                    added=any(e['evidence_id'] not in existing for e in supplement)
                    for item in supplement:
                        if item['evidence_id'] in existing and existing[item['evidence_id']].get('quote')!=item.get('quote'):
                            raise ValidationError('shared source evidence identity changed')
                        existing[item['evidence_id']]=item
                    task['review_evidence']=list(existing.values())
                    if stored and added:
                        task.update(delta_revision=int(task['delta_revision'])+1,status='proposed')
                connection.execute('UPDATE ontology_extension_tasks SET status=?,task_json=?,row_version=row_version+1 WHERE extension_id=?',
                                   (task['status'],canonical_json(task),task['extension_id']))
            extension_id = task["extension_id"]
            case_id = self._ensure_case(connection, candidate["candidate_id"])
            self._charge_cases(connection, [case_id], {"extension_requests": 1}, "extension_subscription:" + case_id + ":" + extension_id,
                               "triple_review", candidate["candidate_id"])
            next_version = int(row["row_version"]) + 1
            connection.execute("INSERT INTO ontology_extension_subscriptions(extension_id,candidate_id,revision,expected_row_version,source_proposal_digest) VALUES(?,?,?,?,?) "
                               "ON CONFLICT(extension_id,candidate_id,revision) DO UPDATE SET expected_row_version=excluded.expected_row_version,source_proposal_digest=excluded.source_proposal_digest,status='active'",
                               (extension_id, candidate["candidate_id"], candidate["revision"], next_version, proposal["proposal_digest"]))
            state = ("schema_unresolved" if task["status"] in {"rejected", "needs_human"} else "reaudit_required" if task["status"] == "published"
                     else "awaiting_ontology_release" if task["status"] == "approved" else "awaiting_ontology_review")
            connection.execute("UPDATE candidates SET workflow_state=?,pending_extension_id=?,row_version=? WHERE candidate_id=?",
                               (state, extension_id, next_version, candidate["candidate_id"]))
            if self.has_graph_history(connection, candidate["candidate_id"]):
                self.mark_graph_dirty(connection, candidate["candidate_id"], "awaiting_ontology_withdraws_old_admission")
            if task['status']=='proposed':
                self.enqueue_job_in_transaction(connection,'ontology_extension',{'extension_id':extension_id,
                    'audit_id':'ontology_audit_'+uuid4().hex})
        return {"task": task, "workflow_state": state, "row_version": next_version}

    def extension_status(self, extension_id, candidate_id=None):
        from .repository import NotFoundError
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM ontology_extension_tasks WHERE extension_id=?", (extension_id,)).fetchone()
            if row is None: raise NotFoundError("ontology extension task not found")
            subscriptions = connection.execute("SELECT * FROM ontology_extension_subscriptions WHERE extension_id=?", (extension_id,)).fetchall()
        if candidate_id and not any(s["candidate_id"] == candidate_id and s["status"] == "active" for s in subscriptions):
            raise NotFoundError("candidate is not subscribed to this extension")
        with self.connect() as connection:
            jobs=connection.execute("SELECT job_id,status,progress_json,lease_expires_at FROM jobs WHERE job_type='ontology_extension' AND json_extract(payload_json,'$.extension_id')=? ORDER BY created_at DESC LIMIT 5",(extension_id,)).fetchall()
        return {**json.loads(row["task_json"]), "status": row["status"], "row_version": row["row_version"], "subscriptions": [dict(s) for s in subscriptions],
                'queue_jobs':[{**dict(j),'progress':json.loads(j['progress_json'])} for j in jobs],
                'execution_status':jobs[0]['status'] if jobs else 'no_consumer_job',
                'publication_status':'awaiting_release' if row['status']=='approved' else row['status']}

    def repair_extension_jobs(self):
        repaired=[]
        with self.transaction(immediate=True) as connection:
            for row in connection.execute("SELECT extension_id FROM ontology_extension_tasks WHERE status='proposed'").fetchall():
                existing=connection.execute("SELECT 1 FROM jobs WHERE job_type='ontology_extension' AND json_extract(payload_json,'$.extension_id')=? LIMIT 1",(row[0],)).fetchone()
                if existing: continue
                repaired.append(self.enqueue_job_in_transaction(connection,'ontology_extension',
                    {'extension_id':row[0],'audit_id':'ontology_audit_'+uuid4().hex}))
        return repaired
