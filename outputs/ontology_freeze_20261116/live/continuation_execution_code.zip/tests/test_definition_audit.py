import unittest
from copy import deepcopy
from types import SimpleNamespace

from ontology_review.definition_audit import aggregate,binding,errors,judge_once,packets,passed
from review_agent.contracts import sha256_json


class DefinitionAuditTests(unittest.TestCase):
    def setUp(self):
        self.members=[{'id':f'v{i}','model_id':f'm{i}','model_identity':f'm{i}','model_family':f'f{i}'} for i in range(3)]
        self.proposal={'task_id':'audit','materials_hash':'frozen','items':[
            {'relation_id':'r1','label':'测试关系1','evidence':[{'evidence_id':'e1'}]},
            {'relation_id':'r2','label':'测试关系2','evidence':[{'evidence_id':'e2'}]}]}
        self.proposal['proposal_digest']=sha256_json(self.proposal)
        self.raw={'assessments':[{'relation_id':f'r{i}','definition_fidelity':'pass','direction':'pass',
            'endpoint_signature':'pass','task_scope':'in_scope','evidence_ids':[f'e{i}'],
            'issue_codes':[],'reason':'原文支持所述方向和端点。'} for i in (1,2)]}

    def votes(self):
        return [{**binding(m,self.proposal),**deepcopy(self.raw),'response_status':'ok','returned_model_id':m['model_id']} for m in self.members]

    def test_complete_independent_committee(self):
        rows=aggregate(self.proposal,self.votes(),self.members)
        self.assertTrue(all(r['status']=='machine_approved' and not r['human_confirmed'] for r in rows))

    def test_anchor_exists_but_semantic_error_quarantines(self):
        votes=self.votes();row=votes[1]['assessments'][0]
        row.update(definition_fidelity='revise',endpoint_signature='fail',issue_codes=['INTEGRAL_ENDPOINT_IS_NOT_PART'])
        result=aggregate(self.proposal,votes,self.members)
        self.assertEqual(['quarantined','machine_approved'],[r['status'] for r in result])
        self.assertEqual(['e1'],result[0]['assessments'][1]['evidence_ids'])

    def test_unknown_or_missing_never_approves(self):
        votes=self.votes();votes[2]['assessments'][1]['direction']='unknown'
        self.assertEqual('quarantined',aggregate(self.proposal,votes,self.members)[1]['status'])
        self.assertTrue(all(r['status']=='quarantined' for r in aggregate(self.proposal,votes[:2],self.members)))

    def test_wrong_binding_or_family_collision_blocks(self):
        votes=self.votes();votes[1]['materials_hash']='other'
        self.assertFalse(any(r['status']=='machine_approved' for r in aggregate(self.proposal,votes,self.members)))
        votes=self.votes();votes[1]['returned_model_id']='m0'
        self.assertFalse(any(r['status']=='machine_approved' for r in aggregate(self.proposal,votes,self.members)))

    def test_cross_item_citation_and_duplicate_rejected(self):
        raw=deepcopy(self.raw);raw['assessments'][0]['evidence_ids']=['e2']
        self.assertTrue(errors(raw,self.proposal))
        raw=deepcopy(self.raw);raw['assessments'][1]=deepcopy(raw['assessments'][0])
        self.assertTrue(errors(raw,self.proposal))

    def test_no_evidence_or_scope_pass(self):
        row=deepcopy(self.raw['assessments'][0]);row['evidence_ids']=[]
        self.assertFalse(passed(row))
        row=deepcopy(self.raw['assessments'][0]);row['task_scope']='unclear'
        self.assertFalse(passed(row))

    def test_tampered_packet_never_sent(self):
        class Client:
            def complete_json(self,*args,**kwargs):raise AssertionError('should never send')
        voter={**self.members[0],'client':Client()};proposal=deepcopy(self.proposal)
        proposal['items'][0]['relation_id']='tampered'
        self.assertTrue(judge_once(voter,proposal)['not_sent'])


if __name__=='__main__':unittest.main()
