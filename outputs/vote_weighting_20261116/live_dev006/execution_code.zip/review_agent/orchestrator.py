"""Bounded evidence-and-validation state machine."""

from __future__ import annotations

import time
import copy
from typing import Any, Dict, Iterable, List, Mapping, Optional

from confidence.calibrator import TripleCalibrator
from confidence.feature_extractor import TripleFeatureExtractor
from confidence.risk_policy import RiskPolicy
from evidence.hierarchical_retriever import retrieve_initial, retrieve_more
from evidence.verification import make_evidence_bundle, verify_evidence_bundle

from .consensus import Committee, aggregate_votes
from .contracts import FEATURE_SCHEMA_VERSION, EVIDENCE_BUNDLE_VERSION, canonical_triple, proposal_digest, sha256_json
from .response_contract import PROMPT_VERSION, CONTRACT_VERSION, CONTEXT_SCOPES, PROMPT_HASH, RESPONSE_SCHEMA
from .explanation import explain_from_verified_records
from .execution import AuditPaused
from .memory import ReviewMemory
from .repository import ReviewRepository
from .validators import judge_independently, model_request_count
from .vote_weighting import committee_policy


MATERIAL_GAP_CODES = {"CONDITION_MISSING", "QUALIFIER_MISMATCH", "DIRECTION_MISMATCH", "EVIDENCE_INSUFFICIENT"}


class Budget:
    def __init__(self, config: Mapping[str, Any], shared=None):
        self.shared = shared
        self.max_rounds = min(2, max(1, int(config.get("max_rounds", 2))))
        self.max_llm_calls = max(0, int(config.get("max_llm_calls_per_candidate", 12)))
        self.max_tool_calls = max(0, int(config.get("max_tool_calls", 6)))
        self.total_timeout_seconds = max(1.0, float(config.get("total_timeout_seconds", 180)))
        self.started_at = time.monotonic()
        self.llm_calls = 0
        self.tool_calls = 0

    def expired(self) -> bool:
        return time.monotonic() - self.started_at >= self.total_timeout_seconds or bool(self.shared and self.shared.exhausted())

    def allow_llm(self, count: int) -> bool:
        if self.expired() or self.llm_calls + count > self.max_llm_calls:
            return False
        if self.shared and not self.shared.reserve_calls(count): return False
        self.llm_calls += count
        return True

    def refund_llm(self, count: int) -> None:
        if self.shared: self.shared.refund_calls(count)
        self.llm_calls = max(0, self.llm_calls - max(0, int(count)))

    def allow_tool(self) -> bool:
        if self.expired() or self.tool_calls + 1 > self.max_tool_calls:
            return False
        if self.shared and not self.shared.consume_tool(): return False
        self.tool_calls += 1
        return True


def malformed_required_fields(candidate: Mapping[str, Any]) -> bool:
    triple = candidate.get("triple") if isinstance(candidate.get("triple"), Mapping) else candidate
    return not all(str(triple.get(key) or "").strip() for key in ("head", "tail")) or not str(
        triple.get("relation_id") or triple.get("surface_relation") or triple.get("relation") or ""
    ).strip()


def bounded_evidence_bundle(
    bundle: Mapping[str, Any], *, max_items: int, max_chars: int,
) -> Dict[str, Any]:
    selected = []
    used_chars = 0
    for item in bundle.get("items") or []:
        if len(selected) >= max(0, max_items):
            break
        item_chars = len(str(item.get("quote") or item.get("text") or ""))
        if item_chars + used_chars > max(0, max_chars):
            continue
        selected.append(item)
        used_chars += item_chars
    limited = {**dict(bundle), **make_evidence_bundle(selected, bundle.get("searched_levels") or [])}
    limited["bounded_character_count"] = used_chars
    limited["truncated_by_budget"] = len(selected) < len(bundle.get("items") or [])
    limited["evidence_hash"] = sha256_json({k: v for k, v in limited.items() if k != "evidence_hash"})
    return limited


class ReviewOrchestrator:
    def __init__(
        self, repository: ReviewRepository, ontology_guard: Any, validators: Iterable[Mapping[str, Any]],
        *, calibrator: Optional[TripleCalibrator] = None, risk_policy: Optional[RiskPolicy] = None,
        config: Optional[Mapping[str, Any]] = None,
        planner_client=None, should_cancel=None,
    ):
        self.repository = repository
        self.ontology_guard = ontology_guard
        self.validators = list(validators)
        self.calibrator = calibrator or TripleCalibrator()
        self.risk_policy = risk_policy or RiskPolicy()
        from .configuration import normalize_config
        self.config = normalize_config(dict(config or {}))
        self.ontology_guard.require_explicit_mapping = self.config.get('validator_contract_version')in {'validator_response_v5','validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'}
        self.ontology_guard.require_relation_definition = self.config.get('validator_contract_version') in {'validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'}
        self.planner_client = planner_client
        self.should_cancel = should_cancel
        consensus_config = dict(self.config.get("consensus") or {})
        voter_ids = [str(item["id"]) for item in self.validators]
        committee_size = int(consensus_config.get("committee_size", 4))
        if len(voter_ids) > committee_size:
            raise ValueError("configured validators exceed the frozen committee size")
        voter_ids.extend(
            f"unconfigured_{index + 1}" for index in range(committee_size - len(voter_ids))
        )
        required = int(consensus_config.get("required_votes", 3))
        self.committee = Committee(
            voter_ids,
            required_votes=required,
            minimum_distinct_families=int(consensus_config.get("minimum_distinct_families", 3)),
            version=str(consensus_config.get("version", "committee_v1")),
            weighting_policy=self.config.get('vote_weighting') if (self.config.get('vote_weighting') or {}).get('mode') != 'legacy' else None,
        )
        from .vote_weighting import committee_policy
        self.committee_policy_hash = sha256_json(committee_policy(self.committee))

    def committee_members(self):
        return [{"id": v["id"],
            "model_id": v.get("model_id") or getattr(v["client"], "model_id", ""),
            "model_identity": v.get("model_identity") or str(v.get("model_id") or getattr(v["client"], "model_id", "")).casefold(),
            "model_family": v.get("model_family") or getattr(v["client"], "model_family", "")}
            for v in self.validators]

    def admission_policy(self):
        from .scope_policy import DEFAULT_POLICY
        return {"mode": self.config.get("mode", "shadow"), "policy_version": self.risk_policy.version,
                "policy_ready": self.risk_policy.ready, "calibrator_ready": bool(getattr(self.calibrator, "ready", False)),
                "accept_threshold": self.risk_policy.policy.get("accept_threshold"),
                "auto_accept_enabled": bool((self.config.get("routing") or {}).get("auto_accept_enabled") and self.risk_policy.policy.get("auto_accept_enabled")),
                **({'scope_policy':self.config.get('scope_policy') or DEFAULT_POLICY} if self.config.get('validator_contract_version')in {'validator_response_v5','validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'} else {})}

    def _proposal(
        self, audit_id: str, candidate: Mapping[str, Any], guard: Mapping[str, Any],
        bundle: Mapping[str, Any], round_id: int, context: Mapping[str, Any],
    ) -> Dict[str, Any]:
        from .response_contract import PROMPT_HASH, RESPONSE_SCHEMA
        seed = {
            "candidate_id": candidate["candidate_id"], "revision": candidate["revision"],
            "candidate_review_hash": sha256_json(candidate), "ontology_check_hash": sha256_json(guard),
            "admission_policy_hash": sha256_json(context.get("admission_policy", {})),
            "canonical_triple": canonical_triple(candidate),
            "document_version": candidate["document_version"],
            "ontology_version": candidate["ontology_version"],
            **{key: candidate.get(key) for key in ("contract_version", "source_index_hash", "ontology_release_id", "profile_hash")},
            "evidence_bundle_hash": bundle["evidence_hash"],
            "prompt_version": PROMPT_VERSION,
            "prompt_hash": PROMPT_HASH, "response_contract_hash": sha256_json(RESPONSE_SCHEMA),
            "response_contract_version": CONTRACT_VERSION,
            "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION,
            "rubric_version": context.get("rubric_version", "triple_review_rubric_v1"),
            "committee_version": self.committee.version,
            "committee_policy_hash": self.committee_policy_hash,
            "committee_policy": committee_policy(self.committee),
            "committee_members": self.committee_members(),
            'validator_generation':[{'voter_id':v['id'],'max_output_tokens':v.get('max_output_tokens',4096)} for v in self.validators],
            "memory_snapshot_id": context.get("memory_snapshot_id", 0),
            "memory_bundle_hash": context.get("memory_bundle_hash"), "round_id": round_id,
            'memory_scope_hash':context.get('memory_scope_hash'),
            'memory_policy_hash':context.get('memory_policy_hash'),
            **({"agent_versions": context["agent_versions"]} if context.get("agent_versions") else {}),
        }
        from .validator_contracts import versions_for
        seed.update(versions_for(self.config))
        if seed['response_contract_version'] in {'validator_response_v7','validator_response_v8'}:
            from .scope_policy import DEFAULT_POLICY
            seed['review_scope_policy'] = copy.deepcopy((context.get('admission_policy') or {}).get('scope_policy') or self.config.get('scope_policy') or DEFAULT_POLICY)
        if seed['response_contract_version'] in {'validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'}:
            from .validator_contracts import contract_for
            from .output_structure import resolve_profile
            schema=contract_for(seed['response_contract_version']).RESPONSE_SCHEMA
            for generation,voter in zip(seed['validator_generation'],self.validators):
                generation['output_transport']=resolve_profile(voter,self.config,schema)
        catalog = None
        ontology_context = None
        mapping_preflight = None
        if seed['response_contract_version']in {'validator_response_v6_3','validator_response_v7','validator_response_v8'}:
            from .ontology_context import select_context
            ontology_context=select_context(self.ontology_guard,candidate,bundle,seed['ontology_context_policy'],
                                            context.get('ontology_retrieval'))
            if 'mapping_preflight_policy' in seed:
                from .mapping_preflight import prepare
                ontology_context, mapping_preflight = prepare(self.ontology_guard, candidate, bundle, ontology_context,
                    seed['ontology_context_policy'], seed['mapping_preflight_policy'], context.get('ontology_retrieval'))
                seed['mapping_preflight_hash'] = sha256_json(mapping_preflight)
            seed['ontology_context_hash']=sha256_json(ontology_context)
            seed['ontology_catalog_hash']=ontology_context['source_catalog_hash']
        elif seed['response_contract_version']in {'validator_response_v5','validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2'}:
            from schema.relation_registry import RelationRegistry
            catalog={**RelationRegistry(self.ontology_guard.ontology).reference_catalog(),
                     'classes':list(self.ontology_guard.classes.values())}
            seed['ontology_catalog_hash']=sha256_json(catalog)
        field_standardization = None
        if seed['response_contract_version'] == 'validator_response_v8':
            from .field_spec import prepare
            field_standardization = prepare(candidate,bundle,seed['field_spec'])
            seed['field_standardization_hash'] = sha256_json(field_standardization)
        dispute_context=None
        if 'dispute_policy' in seed:
            from .disputes import request_context
            dispute_context=request_context(candidate,seed['dispute_policy'])
            seed['dispute_context_hash']=sha256_json(dispute_context)
        return {
            **seed, "audit_id": audit_id, "proposal_digest": proposal_digest(seed),
            "candidate": dict(candidate), "ontology_check": dict(guard),
            "evidence_bundle": dict(bundle), "review_memory": context.get("review_memory", {}),
            "request_cache_namespace": context.get("request_cache_namespace", "default"),
            **({'ontology_catalog':catalog} if catalog is not None else {}),
            **({'ontology_context':ontology_context} if ontology_context is not None else {}),
            **({'mapping_preflight':mapping_preflight} if mapping_preflight is not None else {}),
            **({'field_standardization':field_standardization} if field_standardization is not None else {}),
            **({'dispute_context':dispute_context} if dispute_context is not None else {}),
        }

    def audit_candidate(
        self, candidate_id, revision, document_snapshot, *, context=None,
    ):
        """Persist a terminal failure for both deterministic and planner execution paths."""
        from .repository import NotFoundError
        from .review_observability import redact
        try:previous=self.repository.get_audit(candidate_id).get('audit_id')
        except NotFoundError:previous=None
        try:
            return self._audit_candidate(candidate_id,revision,document_snapshot,context=context)
        except Exception as exc:
            try:audit=self.repository.get_audit(candidate_id,(context or {}).get('audit_id'))
            except NotFoundError:audit=None
            if audit and audit['status']=='running' and (audit['audit_id']!=previous or (context or {}).get('audit_id')==audit['audit_id']):
                self.repository.finish_incomplete_audit(audit['audit_id'],'paused' if isinstance(exc,AuditPaused) else 'failed',{
                    'reason_code':'INSUFFICIENT_BALANCE' if isinstance(exc,AuditPaused) else 'RUNTIME_EXCEPTION','failed_stage':'audit_execution',
                    'error_type':type(exc).__name__,'error':redact(str(exc)),'recoverable':False})
            raise

    def _audit_candidate(
        self, candidate_id: str, revision: int, document_snapshot: Mapping[str, Any],
        *, context: Optional[Mapping[str, Any]] = None,
    ) -> Dict[str, Any]:
        context = {**dict(context or {}), "admission_policy": self.admission_policy()}
        planner = self.config.get("planner") or {}
        if planner.get("enabled") and planner.get("strategy") == "llm_react":
            from .runtime import AgentRuntime
            return AgentRuntime(self).run(candidate_id, revision, document_snapshot, context=context)
        if planner.get("strategy", "deterministic") not in {"deterministic", "llm_react"}:
            raise ValueError("unsupported planner strategy")
        return self._audit_deterministic(candidate_id, revision, document_snapshot, context=context)

    def _audit_deterministic(
        self, candidate_id: str, revision: int, document_snapshot: Mapping[str, Any],
        *, context: Optional[Mapping[str, Any]] = None,
    ) -> Dict[str, Any]:
        planner_config = dict(self.config.get("planner") or {})
        context = {
            "mode": self.config.get("mode", "shadow"),
            "feature_schema_version": FEATURE_SCHEMA_VERSION,
            "planner_strategy": planner_config.get("strategy", "deterministic"),
            "orchestrator_kind": "bounded_state_machine",
            "configured_strategy": planner_config.get("strategy", "deterministic"),
            "executed_strategy": "deterministic",
            **dict(context or {}),
            "prompt_version": PROMPT_VERSION,
            "prompt_hash": PROMPT_HASH,
            "response_contract_hash": sha256_json(RESPONSE_SCHEMA), "committee_policy_hash": self.committee_policy_hash,
            "response_contract_version": CONTRACT_VERSION,
            "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION,
            "committee_version": self.committee.version,
            "committee_members": self.committee_members(),
        }
        candidate = self.repository.get_revision(candidate_id, revision)
        from .validator_contracts import versions_for as validator_versions
        context.update(validator_versions(self.config))
        from .batch import versions_for
        context['memory_policy_hash']=versions_for(self.config)['memory_policy_hash']
        from .memory_scope import resolve_scope,scope_hash
        memory_scope=resolve_scope(self.config,context)
        context.update(memory_scope=memory_scope,memory_scope_hash=scope_hash(memory_scope))
        memory_config = dict(self.config.get("memory") or {})
        if memory_config.get("enabled", True):
            memory = ReviewMemory(self.repository)
            snapshot_id = int(context.get("memory_snapshot_id", memory.current_version()))
            triple = candidate.get("triple") or candidate
            memory_bundle = memory.lookup(
                relation_id=triple.get("relation_id"), domain=candidate.get("domain"),
                snapshot_id=snapshot_id, exclude_candidate_id=candidate_id,
                scope=memory_scope,
                max_positive=int(memory_config.get("max_positive_cases", 3)),
                max_negative=int(memory_config.get("max_negative_cases", 3)),
            )
            context.update({
                "memory_snapshot_id": snapshot_id, "review_memory": memory_bundle,
                "memory_bundle_hash": sha256_json(memory_bundle),
            })
        audit_id = self.repository.start_audit(candidate_id, revision, context)
        guard = self.ontology_guard.check(candidate)
        budget_config = {**dict(self.config.get("budget") or {}),
                         "max_rounds": (self.config.get("consensus") or {}).get("max_rounds", 2)}
        from .case_budget import CaseBudget
        case_id = self.repository.ensure_case(candidate_id, self.config.get("case_budget"))
        budget = Budget(budget_config, CaseBudget({**budget_config, "max_llm_calls_per_candidate": budget_config.get("max_llm_calls_per_candidate", 12)},
            self.repository, [case_id], task_type="triple_review", task_id=audit_id))
        max_evidence_items = max(0, int(budget_config.get("max_evidence_items", 12)))
        max_evidence_chars = max(0, int(budget_config.get("max_evidence_chars", 12_000)))
        bundle = bounded_evidence_bundle(
            verify_evidence_bundle(retrieve_initial(
                dict(candidate), dict(document_snapshot),
                max_items=min(6, max_evidence_items),
            ), document_snapshot, candidate),
            max_items=max_evidence_items, max_chars=max_evidence_chars,
        )
        last_votes: List[Dict[str, Any]] = []
        if self.config.get('validator_contract_version')in {'validator_response_v5','validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'}:
            from evidence.units import enrich_bundle
            expanded=enrich_bundle(bundle,document_snapshot,candidate)
            expanded['items'].sort(key=lambda x:x.get('substantive') is False)
            bundle=bounded_evidence_bundle(expanded,max_items=max_evidence_items,max_chars=max_evidence_chars)
        consensus: Dict[str, Any] = aggregate_votes([], self.committee)
        gaps: Dict[str, Any] = {"need_more_evidence": False}
        from .agent_state import AgentState
        from .issue_ledger import IssueLedger
        lifecycle = AgentState(candidate=dict(candidate), context=context, audit_id=audit_id)
        ledger = IssueLedger(lifecycle)
        ledger.inherit(self.repository)
        if lifecycle.archive:
            bundle = bounded_evidence_bundle(verify_evidence_bundle(make_evidence_bundle(
                [*lifecycle.archive, *bundle["items"]], bundle.get("searched_levels", [])), document_snapshot, candidate),
                max_items=max_evidence_items, max_chars=max_evidence_chars)
        final_round = 0
        for round_id in range(1, budget.max_rounds + 1):
            final_round = round_id
            proposal = self._proposal(audit_id, candidate, guard, bundle, round_id, context)
            configured_retries = max(0, int(
                (self.config.get("budget") or {}).get("max_retries_per_request", 1)
            ))
            base_calls = len(self.validators)
            remaining_calls = max(0, budget.max_llm_calls - budget.llm_calls)
            effective_retries = min(
                configured_retries,
                max(0, (remaining_calls - base_calls) // max(1, base_calls)),
            )
            reserved_calls = base_calls * (1 + effective_retries)
            calls_allowed = bool(self.validators and bundle.get("items") and budget.allow_llm(reserved_calls))
            call_budget_exhausted = bool(self.validators and bundle.get("items") and not calls_allowed)
            if calls_allowed:
                try:
                    last_votes = judge_independently(
                        self.validators, proposal,
                        max_workers=int((self.config.get("budget") or {}).get("max_parallel_validators", 4)),
                        max_retries=effective_retries,
                        repository=self.repository,
                        per_call_timeout_seconds=min(
                            float(budget_config.get("per_call_timeout_seconds", 45)),
                            max(.001, budget.total_timeout_seconds - (time.monotonic() - budget.started_at))),
                    )
                except AuditPaused as exc:
                    self.repository.append_round(audit_id, proposal, [exc.vote],
                        aggregate_votes([exc.vote], self.committee, proposal_digest=proposal["proposal_digest"]),
                        {"stop_reason": "insufficient_balance", "pause_job": True})
                    self.repository.finish_incomplete_audit(audit_id, "paused", {
                        "reason_code": "INSUFFICIENT_BALANCE", "voter_id": exc.vote.get("voter_id"),
                        "error": str(exc),
                    })
                    raise
                actual_calls = sum(model_request_count(vote) for vote in last_votes)
                budget.refund_llm(reserved_calls - actual_calls)
                for vote in last_votes:
                    for attempt in vote.get("attempts", []): budget.shared.tokens(attempt)
            else:
                last_votes = []
            preliminary = aggregate_votes(last_votes, self.committee, proposal_digest=proposal["proposal_digest"], proposal=proposal)
            ledger.observe(proposal, last_votes, preliminary, self.committee.required_votes)
            material_counter = any(
                vote.get("response_status") == "ok" and vote.get("verdict") == "invalid"
                and vote.get("counter_evidence_ids") for vote in last_votes
            ) and preliminary.get("valid_votes", 0) > 0
            material_support = any(
                vote.get("response_status") == "ok" and vote.get("source_support") == "supported"
                and vote.get("supporting_evidence_ids") for vote in last_votes
            ) and any(v.get("response_status") == "ok" and v.get("source_support") == "contradicted"
                      and v.get("counter_evidence_ids") for v in last_votes)
            material_reason = any(
                set(vote.get("reason_codes") or []) & MATERIAL_GAP_CODES for vote in last_votes
                if vote.get("response_status") == "ok"
            )
            consensus = aggregate_votes(
                last_votes, self.committee, proposal_digest=proposal["proposal_digest"],
                proposal=proposal,
                admission_blocked=any(i.get("critical") for i in ledger.unresolved()),
                unresolved_counterevidence=any(i["code"] in {"source_conflict", "counterevidence"} for i in ledger.unresolved()),
                unresolved_support_conflict=any(i["code"] in {"source_conflict", "counterevidence"} for i in ledger.unresolved()),
            )
            gaps = {
                "need_more_evidence": bool(material_counter or material_support or material_reason
                    or not bundle.get("items") or any(v.get("requested_context") or
                    (v.get("response_status") == "ok" and v.get("source_support") == "insufficient") for v in last_votes)),
                "unresolved_counterevidence": material_counter,
                "unresolved_support_conflict": material_support,
                "ontology_disagreement": any(v.get("ontology_disagreement") for v in last_votes),
                "material_reason": material_reason,
                "budget_exhausted": call_budget_exhausted,
                "critical_issues_unresolved": any(i.get("critical") for i in ledger.unresolved()),
                "protected_evidence_omitted": bool(set(lifecycle.protected_ids) - {i["evidence_id"] for i in bundle["items"]}),
            }
            if self.committee.weighting_policy and consensus.get('result')=='accept_consensus' and not material_counter and not material_support:
                gaps['need_more_evidence']=False
            self.repository.append_round(audit_id, proposal, last_votes, consensus, gaps)
            if call_budget_exhausted or not gaps["need_more_evidence"] or round_id >= budget.max_rounds:
                gaps["stop_reason"] = ("call_budget_exhausted" if call_budget_exhausted else
                    "round_limit" if gaps["need_more_evidence"] else
                    "committee_unresolved" if consensus["result"] == "unresolved" else "resolved")
                self.repository.update_round_gaps(audit_id, round_id, gaps)
                break
            request = next((vote.get("requested_context") for vote in last_votes if vote.get("requested_context")), None)
            request = dict(request or {"scope": "current_chunk", "query": "补充限定条件与反证", "limit": 4})
            trace, extra_items = [], []
            scopes = list(CONTEXT_SCOPES)
            first = scopes.index(request["scope"])
            retrieval_candidate = dict(candidate)
            if bundle.get("items"):
                retrieval_candidate["source_chunk_id"] = bundle["items"][0]["chunk_id"]
            for scope in scopes[first:]:
                if not budget.allow_tool():
                    gaps["budget_exhausted"] = True
                    break
                actual_request = {**request, "scope": scope}
                extra = verify_evidence_bundle(retrieve_more(
                    retrieval_candidate, dict(document_snapshot), actual_request,
                    [item["evidence_id"] for item in bundle.get("items", [])],
                    max_chars=max_evidence_chars,
                ), document_snapshot, candidate)
                trace.append({"request": actual_request, "returned": len(extra["items"]),
                              "rejected_items": extra.get("rejected_items", [])})
                if extra.get("items"):
                    extra_items = extra["items"]
                    break
            gaps["retrieval_trace"] = trace
            if not extra_items:
                gaps["stop_reason"] = "budget_exhausted" if gaps["budget_exhausted"] else "no_new_evidence"
                self.repository.update_round_gaps(audit_id, round_id, gaps)
                break
            next_bundle = bounded_evidence_bundle(
                verify_evidence_bundle({**make_evidence_bundle(
                    [*bundle.get("items", []), *extra_items],
                    [*bundle.get("searched_levels", []), *[t["request"]["scope"] for t in trace]],
                ), "rejected_items": bundle.get("rejected_items", [])}, document_snapshot, candidate),
                max_items=max_evidence_items, max_chars=max_evidence_chars,
            )
            if {i["evidence_id"] for i in next_bundle["items"]} == {i["evidence_id"] for i in bundle["items"]}:
                gaps["stop_reason"] = "evidence_budget_no_change"
                self.repository.update_round_gaps(audit_id, round_id, gaps)
                break
            bundle = next_bundle
            self.repository.update_round_gaps(audit_id, round_id, gaps)

        context.update(issue_history=lifecycle.issues, evidence_exclusions=lifecycle.evidence_exclusions)
        self.repository.record_issue_events(audit_id, lifecycle.issue_events)
        self.repository.update_audit_context(audit_id, context)
        return self._finalize(candidate, context, audit_id, guard, bundle, last_votes, consensus, gaps,
                              final_round, {"llm_calls": budget.llm_calls, "tool_calls": budget.tool_calls})

    def _finalize(self, candidate, context, audit_id, guard, bundle, last_votes, consensus, gaps,
                  final_round, usage):
        candidate_id, revision = candidate["candidate_id"], candidate["revision"]
        gaps = dict(gaps)
        if candidate.get("contract_version") == "extraction_candidate_v4" and candidate.get("fact_key_state") != "canonical":
            gaps["identity_unresolved"] = True
        rounds = self.repository.get_audit(candidate_id, audit_id)["rounds"]
        selected = next((p for p in rounds if p["round_id"] == final_round), None)
        from .resolution_state import from_context,apply_consensus
        snapshot=from_context(selected,last_votes,self.committee,context) if selected else None
        scoped=bool(snapshot and (snapshot['accepted_resolutions'] or snapshot.get('accepted_semantic_review_ids') or snapshot.get('accepted_original_receipt_ids')) and not snapshot['new_obligations'])
        if (not selected or (selected["evidence_bundle"]["evidence_hash"] != bundle.get("evidence_hash") and not scoped)
                or any(v.get("round_id") != final_round or v.get("proposal_digest") != selected["proposal_digest"] for v in last_votes)):
            selected = None
            gaps["validation_missing"] = True
        if selected:
            consensus = aggregate_votes(last_votes, self.committee, proposal=selected, proposal_digest=selected["proposal_digest"],
                unresolved_counterevidence=bool(gaps.get("unresolved_counterevidence")),
                unresolved_support_conflict=bool(gaps.get("unresolved_support_conflict")),
                admission_blocked=any(gaps.get(key) for key in ("critical_issues_unresolved", "protected_evidence_omitted",
                    "unreviewed_discovered_evidence", "validation_missing", "version_stale", "ontology_not_checked", "identity_unresolved")))
            consensus=apply_consensus(consensus,snapshot)
        independently_reviewed=bool(selected and not gaps.get('ontology_not_checked')
            and set(consensus.get('eligible_voter_ids',[]))==set(self.committee.voter_ids)
            and consensus.get('distinct_family_count',0)>=self.committee.minimum_distinct_families)
        if self.committee.weighting_policy:
            independently_reviewed = bool(selected and not gaps.get('ontology_not_checked') and consensus.get('weighted_review_complete'))
        completion=('independent_review_completed' if independently_reviewed else
            'independent_review_incomplete' if selected else
            'manual_handoff_no_evidence' if context.get('review_completion_status')=='manual_handoff_no_evidence' and not bundle.get('items') else
            'not_independently_reviewed')
        context.update(review_completion_status=completion,independent_review_completed=independently_reviewed)
        self.repository.update_audit_context(audit_id,{'review_completion_status':completion,'independent_review_completed':independently_reviewed})
        features = TripleFeatureExtractor().extract_v3(
            candidate, guard, bundle, last_votes, consensus,
            round_count=final_round,
            retrieval_depth=len(bundle.get("searched_levels", [])),
        )
        calibration = self.calibrator.predict_if_compatible(features, {
            "domain": candidate.get("domain"), "committee_version": self.committee.version,
            "prompt_version": context.get('prompt_version',PROMPT_VERSION),
            "response_contract_version": context.get('response_contract_version',CONTRACT_VERSION),
            "evidence_bundle_version": EVIDENCE_BUNDLE_VERSION,
            **{key: context.get(key) for key in ("prompt_hash", "response_contract_hash", "committee_policy_hash", "memory_scope_hash", "memory_policy_hash")},
            **{key: context[key] for key in context if key.startswith("planner_") or key in {"executed_strategy", "configured_strategy"}},
        })
        route = self.risk_policy.route_v3(
            guard=guard, evidence=bundle, consensus=consensus, probability=calibration,
            gaps=gaps, frozen=context, malformed_required_fields=malformed_required_fields(candidate),
        )
        routing = dict(self.config.get("routing") or {})
        route_disabled = (
            route["decision"] == "auto_accept" and not routing.get("auto_accept_enabled", False)
        ) or (
            route["decision"] == "auto_reject" and not routing.get("semantic_auto_reject_enabled", False)
        )
        if route_disabled:
            route = {
                "decision": "manual_review",
                "reason_codes": [*route.get("reason_codes", []), "AUTOMATIC_ROUTE_DISABLED"],
            }
        elif route["decision"] in {"auto_accept", "auto_reject"} and context.get("mode") != "active":
            route = {
                "decision": "manual_review",
                "reason_codes": [*route.get("reason_codes", []), "NON_ACTIVE_MODE_REQUIRES_HUMAN"],
            }
        explanation = explain_from_verified_records(candidate, guard, bundle, last_votes, route)
        source_result = consensus.get("source_support_consensus", {}).get("result", "unresolved")
        workflow = context.get("workflow_state") or "manual_review"
        if workflow not in {"awaiting_ontology_review", "awaiting_ontology_release", "reaudit_required", "schema_unresolved"}:
            if any(i.get("requires_revision") and i.get("status", "open") != "resolved" for i in context.get("issue_history", [])):
                workflow = "revision_required"
            elif any(v.get("schema_issue") == "candidate_mapping_error" for v in last_votes):
                workflow = "revision_required"
            elif source_result == "supported" and guard.get("status") != "pass":
                workflow = "schema_unresolved"
            elif source_result == "contradicted" or route["decision"] in {"auto_accept", "auto_reject"}:
                workflow = "review_completed"
            else: workflow = "manual_review"
        scope_decision = None
        if selected and selected.get('response_contract_version')in {'validator_response_v5','validator_response_v5_1','validator_response_v5_2','validator_response_v6','validator_response_v6_1','validator_response_v6_2','validator_response_v6_3','validator_response_v7','validator_response_v8'}:
            from .scope_policy import scope_route
            scope_decision = scope_route(consensus.get('core_source_support_result',source_result),
                consensus.get('expression_status','unresolved'), consensus.get('effective_mapping_status',consensus.get('mapping_status','ambiguous')),
                consensus.get('knowledge_scope','unresolved'), policy=(selected or {}).get('review_scope_policy') or (context.get('admission_policy') or {}).get('scope_policy') or self.config.get('scope_policy'),
                scope_confirmed=consensus.get('scope_confirmed',False))
            waiting_for_extension=bool(context.get('pending_extension_id')) and workflow in {'awaiting_ontology_review','awaiting_ontology_release','reaudit_required'}
            if scope_decision['workflow_state'] in {'excluded_by_scope','revision_required','mapping_review','scope_review'} and not (
                    waiting_for_extension and scope_decision['workflow_state']=='mapping_review'):
                workflow=scope_decision['workflow_state']
                route={'decision':'manual_review','reason_codes':[*route.get('reason_codes',[]),
                    'EXCLUDED_BY_SCOPE' if workflow=='excluded_by_scope' else workflow.upper()]}
            explanation=explain_from_verified_records(candidate,guard,bundle,last_votes,route)
        result = {
            "audit_id": audit_id, "candidate_id": candidate_id, "revision": revision,
            "review_completion_status":context.get('review_completion_status','legacy_unclassified'),
            "independent_review_completed":bool(context.get('independent_review_completed',False)),
            "final_round_id": final_round, "consensus": consensus,
            "calibrated_probability": calibration.probability,
            "calibration_status": calibration.status, "calibrator_version": calibration.model_version,
            "policy_version": self.risk_policy.version,
            "decision": route["decision"], "reason_codes": route.get("reason_codes", []),
            "review_versions": {field: context[field] for field in (
                "prompt_version", "prompt_hash", "response_contract_hash", "committee_policy_hash", "memory_scope_hash", "memory_policy_hash", "response_contract_version", "evidence_bundle_version", "committee_version",
                "planner_prompt_version", "planner_prompt_hash", "planner_contract_version", "planner_strategy_version", "planner_model_id",
                "planner_model_family", "configured_strategy", "executed_strategy", "summary_policy_version", "summary_policy_hash", "output_delivery_version", "output_delivery_hash", "correction_policy_version", "correction_policy_hash") if field in context},
            "features": features, "feature_schema_version": FEATURE_SCHEMA_VERSION,
            "explanation": explanation, "budget": usage,
            "configured_strategy": context.get("configured_strategy", "deterministic"),
            "executed_strategy": context.get("executed_strategy", "deterministic"),
            **({'failure_handling':context['failure_handling']} if context.get('failure_handling') else {}),
            "stop_reason": gaps.get("stop_reason"),
            "workflow_state": workflow, "pending_extension_id": context.get("pending_extension_id") or None,
            "source_support_result": source_result, "schema_status": guard.get("status"),
            "schema_diagnostics": sorted({v.get("schema_issue") for v in last_votes if v.get("schema_issue")}),
            "source_support_consensus": consensus.get("source_support_consensus", {}),
            "admission_consensus": consensus.get("admission_consensus", {}),
            "selected_round_id": final_round if selected else None,
            "selected_proposal_digest": selected["proposal_digest"] if selected else None,
            "selected_evidence_hash": selected["evidence_bundle"]["evidence_hash"] if selected else None,
            "committee_version": self.committee.version,
            **{key: candidate.get(key) for key in ("ontology_release_id", "profile_hash", "ontology_version")},
            "issue_history": context.get("issue_history", []),
            "evidence_exclusions": context.get("evidence_exclusions", {}),
            "admission_policy": context.get("admission_policy", {}),
            **({'scope_policy_decision':scope_decision} if scope_decision else {}),
        }
        admission = None
        if context.get('response_contract_version') in {'validator_response_v7','validator_response_v8'}:
            from .review_axes import route_axes, VERSION
            axes = consensus.get('review_axes') or {'version': VERSION, 'source': {'status': 'unresolved'},
                'expression': {'status': 'unresolved'}, 'mapping': {'status': 'context_incomplete'}, 'scope': {'status': 'unclear'}}
            axes_route = route_axes(axes, complete=result['independent_review_completed'] and
                (context.get('failure_handling') or {}).get('minimum_review_status')!='incomplete')
            result.update(review_axes=axes, pending_actions=axes_route['pending_actions'])
            if not axes_route['ready_for_admission']:
                result.update(decision='manual_review', workflow_state=axes_route['workflow_state'])
                result['admission_consensus'] = {'result': 'unresolved'}
                result['reason_codes'] = sorted(set(result['reason_codes']) | set(a.upper() for a in axes_route['pending_actions']))
        if selected and selected.get('response_contract_version') in {'validator_response_v7','validator_response_v8'}:
            from .review_observability import outcome
            if context.get('resolution_snapshots_enabled'):
                from .resolution_status import technical_tasks
                context['technical_recovery_tasks']=technical_tasks(self.repository,audit_id)
                self.repository.update_audit_context(audit_id,{'technical_recovery_tasks':context['technical_recovery_tasks'],
                    'human_problem_cards':context.get('human_problem_cards',[])})
            result['review_outcome']=outcome(selected,last_votes,self.committee,
                context={**context,'final_gaps':gaps},decision=result,stop_reason=gaps.get('stop_reason'))
            if self.committee.weighting_policy:
                result.update(weight_snapshot=result['review_outcome']['weight_snapshot'],
                    research_operation=result['review_outcome']['research_operation'],
                    research_operation_basis=result['review_outcome']['blocking_reasons'])
            if snapshot:
                result.update(resolution_snapshot_id=snapshot['snapshot_id'],resolution_snapshot=snapshot)
            if context.get('resolution_snapshots_enabled'):
                result.update({k:result['review_outcome'][k] for k in ('semantic_status','technical_status','required_human_action')})
                result['human_problem_cards']=context.get('human_problem_cards',[])
        if result["decision"] == "auto_accept":
            from .repository import UnprocessableEntityError
            try:
                admission = self.repository.prepare_automatic_admission(candidate_id, revision, result)
                result["admission"] = admission["result"]
            except UnprocessableEntityError as exc:
                result.update(decision="manual_review", workflow_state="manual_review", admission={"allowed": False, "error": str(exc)})
                result["reason_codes"] = [*result["reason_codes"], "UNIFIED_ADMISSION_BLOCKED"]
        result["committed"] = self.repository.commit_audit_if_current(
            candidate_id, revision, audit_id, result, prepared_admission=admission
        )
        return result
